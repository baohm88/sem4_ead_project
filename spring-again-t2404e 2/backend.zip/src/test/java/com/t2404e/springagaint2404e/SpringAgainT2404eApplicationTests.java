package com.t2404e.springagaint2404e;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAgainT2404eApplicationTests {

    @Test
    void contextLoads() {
    }

}
