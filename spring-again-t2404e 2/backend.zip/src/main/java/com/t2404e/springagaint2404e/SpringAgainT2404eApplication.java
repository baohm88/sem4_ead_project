package com.t2404e.springagaint2404e;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAgainT2404eApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAgainT2404eApplication.class, args);
    }

}
